# Introduction to Prolog #
This repository contains some explanation and examples that should help you learn Prolog.

All the examples from this repository can be downloaded [here](https://github.com/COMS30106/prolog_intro/archive/master.zip), and accompanying explanations are in the [wiki](https://github.com/COMS30106/prolog_intro/wiki).
