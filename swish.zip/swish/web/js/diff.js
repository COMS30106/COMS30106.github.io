/*  Part of SWISH

    Author:        Jan Wielemaker
    E-mail:        J.Wielemaker@cs.vu.nl
    WWW:           http://www.swi-prolog.org
    Copyright (C): 2015-2016, VU University Amsterdam
			      CWI Amsterdam
    All rights reserved.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.

    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in
       the documentation and/or other materials provided with the
       distribution.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
    "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
    FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
    COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
    LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
    ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
    POSSIBILITY OF SUCH DAMAGE.
*/

/**
 * @fileOverview
 * View diffs between versions
 *
 * @version 0.2.0
 * @author Jan Wielemaker, J.Wielemaker@vu.nl
 * @requires jquery
 */

define([ "jquery", "difflib", "diffview" ],
       function() {

(function($) {
  var pluginName = 'diff';

  /** @lends $.fn.diff */
  var methods = {
    /**
     * Render diff between two strings in the target element (must
     * be a `<div>`).
     *
     * @param {Object} [options]
     * @param {String} [base] Old version
     * @param {String} [head] New version
     * @param {String} [baseName="Base text"] Name for old version
     * @param {String} [headName="Current text"] Name for current version
     * @param {Number} [context=3] Number of context lines
     */
    _init: function(options) {
      return this.each(function() {
	var base        = difflib.stringAsLines(options.base);
	var newtxt      = difflib.stringAsLines(options.head);
	var sm          = new difflib.SequenceMatcher(base, newtxt);
	var opcodes     = sm.get_opcodes();
	var contextSize = options.contextSize == undefined
				? 3 : options.contextSize;

	this.appendChild(diffview.buildView(
	  { baseTextLines: base,
	    newTextLines: newtxt,
	    opcodes: opcodes,
	    baseTextName: options.baseName || "Base text",
	    newTextName:  options.headName || "Current text",
	    contextSize: contextSize,
	    viewType: $("inline").checked ? 1 : 0
	  }));
      });
    }
  }; // methods

  /**
   * This class is a jQuery wrapper around
   *
   * @class diff
   * @tutorial jquery-doc
   * @memberOf $.fn
   * @param {String|Object} [method] Either a method name or the jQuery
   * plugin initialization object.
   * @param [...] Zero or more arguments passed to the jQuery `method`
   */

  $.fn.diff = function(method) {
    if ( methods[method] ) {
      return methods[method]
	.apply(this, Array.prototype.slice.call(arguments, 1));
    } else if ( typeof method === 'object' || !method ) {
      return methods._init.apply(this, arguments);
    } else {
      $.error('Method ' + method + ' does not exist on jQuery.' + pluginName);
    }
  };
}(jQuery));
});
