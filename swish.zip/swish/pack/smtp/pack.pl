name(smtp).
title('An (E)SMTP client for sending mail').
version('1.0.0').
keywords([smtp, mail, sendmail]).
author('Jan Wielemaker', 'J.Wielemaker@vu.nl').
home('https://github.com/JanWielemaker/smtp').
download('https://github.com/JanWielemaker/smtp/releases/*.zip').
