# SWISH application packs

This directory is attached  to  SWISH   as  a  provider  for application
specific packages. This works particularly  well   for  add-ons that are
available as a git repository as we can   register  the package as a git
submodule and thus have full control over the version.
