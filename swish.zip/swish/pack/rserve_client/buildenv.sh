# This file contains the environment that can be used to
# build the foreign pack outside Prolog.  This file must
# be loaded into a bourne-compatible shell using
#
#   $ source buildenv.sh

PATH='/swipl/lib/swipl-7.7.0/bin/x86_64-linux:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'
SWIPL='/swipl/lib/swipl-7.7.0/bin/x86_64-linux/swipl'
SWIPLVERSION='70700'
SWIHOME='/swipl/lib/swipl-7.7.0'
SWIARCH='x86_64-linux'
PACKSODIR='lib/x86_64-linux'
SWISOLIB=''
SWILIB='-lswipl'
CC='gcc'
LD='gcc'
CFLAGS='-pthread -fPIC  -I"/swipl/lib/swipl-7.7.0/include"'
LDSOFLAGS='-rdynamic  -pthread -Wl,-rpath=/swipl/lib/swipl-7.7.0/lib/x86_64-linux  -shared'
SOEXT='so'
HOME='/root'

export  PATH SWIPL SWIPLVERSION SWIHOME SWIARCH PACKSODIR SWISOLIB SWILIB CC LD CFLAGS LDSOFLAGS SOEXT HOME
